<?php
require("abstract.databoundobject.php");
class DataAlex extends DataBoundObject{

        protected $id;
        protected $paraula;
        protected $total;
        protected $ultima_visita;


        protected function DefineTableName() {
                return("dataalex");
        }

        protected function DefineRelationMap() {
                return(array(
                        "id" => "id",
                        "paraula" => "paraula",
                        "total" => "total",
                        "lastvisit" => "ultima_visita"));
        }
}


?>