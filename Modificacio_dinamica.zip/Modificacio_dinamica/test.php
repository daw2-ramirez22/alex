<?php
require("class.Dades.php");
require("class.pdofactory.php");

$strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
$objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex", array());
$objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if(isset($_POST["palabra"])){
    $textBusqueda = $_POST["palabra"];
    

    
    $strQuery = "SELECT * FROM dataalex 

    WHERE paraula like '$textBusqueda%' ORDER BY total DESC LIMIT 5";
    $objStatement = $objPDO->prepare($strQuery);
    

    $objStatement->execute();
    
    $arParaules = $objStatement->fetchAll(PDO::FETCH_ASSOC);


    if(empty($arParaules)){
        $paraules = new DataAlex($objPDO);
        $paraules->setparaula($textBusqueda)->settotal(1)->setultima_visita(date("Y-m-d H:i:s"));
        $paraules->Save();

    }else{
        $strQuery = "SELECT * FROM dataalex 
        WHERE paraula = '$textBusqueda'";
        $objStatement = $objPDO->prepare($strQuery); 
        $objStatement->execute();
        $arParaules = $objStatement->fetchAll(PDO::FETCH_ASSOC);

        $jsondata = array();
        $arIds = array();
        foreach($arParaules as $value){
            $id = $value['id'];
            $total = $value['total'];
            $objDatoExistente = new DataAlex($objPDO, $id);            
            $objDatoExistente->settotal($total+1)->setultima_visita(date("Y-m-d H:i:s"));
            $objDatoExistente->Save();
            $paraula = $value['paraula'];
            array_push($jsondata, $paraula);
            array_push($arIds, $id);
        }
            header('Content-type: application/json; charset=utf-8');
            echo json_encode($jsondata,JSON_FORCE_OBJECT);
    }
}

if(isset($_POST["submit"])){
    $textBusqueda = $_POST["submit"];

    $strQuery = "SELECT * FROM dataalex  
    
    WHERE paraula like '$textBusqueda%' ORDER BY total DESC LIMIT 5";
    $objStatement = $objPDO->prepare($strQuery);

    $objStatement->execute();
    $arParaules = $objStatement->fetchAll(PDO::FETCH_ASSOC);

    $jsondata = array();
    foreach($arParaules as $value){
        $id = $value['id'];
        $paraula = $value['paraula'];
        $total = $value['total'];
        $visita = $value['lastvisit'];

        array_push($jsondata, $id, $paraula, $total, $visita);
    }
    header('Content-type: application/json; charset=utf-8');
    echo json_encode($jsondata,JSON_FORCE_OBJECT);
}
?>
